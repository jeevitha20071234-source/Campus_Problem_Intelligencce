# CampusPulse — Complete Runnable Web App

This folder contains a complete runnable CampusPulse web app: an Express backend, SQLite database, JWT authentication, and a responsive browser frontend served from the same Node.js process.

## Run locally

```bash
cd campuspulse-backend
npm install
cp .env.example .env
npm start
```

Open **http://localhost:4000** in your browser.

The SQLite database is created automatically. For development, the default database file is `campuspulse.db`.

## Included files

```text
server.js              Express API, database, authentication, and static hosting
package.json           Node.js dependencies and scripts
.env.example           Environment variable template
public/index.html      Frontend HTML shell
public/app.js          Frontend authentication, dashboard, reports, and profile logic
public/styles.css      Frontend responsive styling
README.md              Setup and API instructions
```

## Main API routes

| Method | Route | Auth | Purpose |
|---|---|---:|---|
| GET | `/api/health` | No | Health check |
| POST | `/api/auth/register` | No | Create account |
| POST | `/api/auth/login` | No | Login and receive JWT |
| GET | `/api/auth/me` | Bearer JWT | Current profile |
| GET | `/api/campus/reports` | Bearer JWT | List reports |
| POST | `/api/campus/reports` | Bearer JWT | Submit report |
| PATCH | `/api/campus/reports/:id` | Manager role | Update report |
| GET | `/api/campus/workers` | Manager role | List workers |
| GET | `/api/notifications` | Bearer JWT | List notifications |

## Competition deployment checklist

Use a strong random `JWT_SECRET`, configure `FRONTEND_ORIGIN` if the frontend is hosted separately, use HTTPS, and replace SQLite with PostgreSQL or MySQL if deploying multiple server instances. Do not commit a real `.env` file or production secrets.
